## Point of Sale (Card Present)

 This page would contain information specific to our support for Card Present