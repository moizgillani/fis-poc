## Payment requests using WP Issued OMNITokens

This page would contain information specific to card based payments using a WP Security Token in place of the PCI.