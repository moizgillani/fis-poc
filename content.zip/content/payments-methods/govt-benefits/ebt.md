## Payment requests using EBT

 This page would contain information specific to our support for EBT