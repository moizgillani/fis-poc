## Payment requests using Merchant Gift Cards

 This page would contain information specific to our support for Merchant Gift Cards