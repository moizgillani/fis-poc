## Payment requests using GooglePay

 This page would contain information specific to our support for GooglePay