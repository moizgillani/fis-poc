## How to get a test account?

Do you wanna try out our payment APIs at your own pace?

If so, you need to get registered so we can give you your own set of **test credentials**.

Talk about API Key in the request header...

.. Add Instructions about how to sign up..