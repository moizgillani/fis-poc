## How to go Live?

This page would contain information about how to go live

Talk about:
* Certification Testing

Talk about:
* Production API Key
* Production Merchant Account No
* Production URL