## AVS (Address Verification System) Result Codes

The **currency ** codes that can be used by the Worldpay Global CNP Payment API are listed below. 