## ISO-3166 Country Codes

The **country ** codes that can be used by the Worldpay Global CNP Payment API are listed below. 

To see whether your setup can leverage these countries (and in what capacity), speak to your Implementation Manager.


| Country| Code|
| --- | --- | 
| Canada|CAN| 
| France|FRA | 
| Germany| DEU |
| Ireland|IRE  | 
| Italy | ITA | 
| United Kingdom| GBR|
| United States of America | USA| 