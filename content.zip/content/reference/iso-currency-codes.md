## ISO-4217 Currency Codes

The **currency ** codes that can be used by the Worldpay Global CNP Payment API are listed below. 

To see whether your setup can integrate with these currencies (and in what capacity), speak to your Implementation Manager.


| Code |Minor Digits| Currency|Locations  |
| --- | --- | --- |--- |
| CAD| 2 |Canadian Dollar  | |
| USD |2  | United States Dollar| |
