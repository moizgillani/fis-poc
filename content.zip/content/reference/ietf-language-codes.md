## IETF Language (Locale) Tags

The **Language ** codes that can be used by the Worldpay Global CNP Payment API are listed below. 
 
| Language| Code|
| --- | --- | 
| English|en| 
| German|de| 
| French| fr|
| Italian|it| 
| Spanish| es | 
| Polish	| pl|
| Chinese | zh| 