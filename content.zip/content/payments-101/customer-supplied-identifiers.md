## Customer Supplied Identifiers

Our payment API contains a set of fields to hold User Defined Data (or Transaction Identifiers),

These data values are stored as part of the transaction and are available on a number of portals and reports that you can use.

![alt text](https://res.cloudinary.com/apimatic/image/upload/v1701603623/63ad9a7735191778f8a5d33c/63ad9a7735191778f8a5d33c--Customer%20Defined%20Fields.png)