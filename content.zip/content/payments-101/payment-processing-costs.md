## Payment Processing Parties and Costs

The diagram below describes the parties involved in processing a payment transaction and the associated fees that a merchant will be charged.

![alt text](https://res.cloudinary.com/apimatic/image/upload/v1701535050/63ad9a7735191778f8a5d33c/63ad9a7735191778f8a5d33c--Credit%20Card%20Fees%20v2.png)
