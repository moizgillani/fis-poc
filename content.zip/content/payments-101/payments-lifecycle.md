## Payment Lifecycle

The diagram below helps you understand the series of statuses a payment goes thru in its lifecycle.

![alt text](https://res.cloudinary.com/apimatic/image/upload/v1701532222/63ad9a7735191778f8a5d33c/63ad9a7735191778f8a5d33c--Paymt%20Lifecycle%20v2.png)

